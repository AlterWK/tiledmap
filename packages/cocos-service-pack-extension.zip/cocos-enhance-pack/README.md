1.修改 package.json 中涉及的版本信息
2.修改 packages 目录，增加相应引擎的备份文件
3.修改 config.json 增加相应版本信息
4.上传引擎文件到 downloadcdn.smallmain.com 和百度网盘
5.更新到 Cocos Store，并更新相应的信息
