'use strict';
const fs = require('fs');
const path = require('path');
var http = require('http');
const extract = require('extract-zip');

/**
 * 公共函数
 */
function unzipFile(path, dest) {
    return new Promise((resolve, reject) => {
        const signal = unzip.Extract({ path: dest });
        fs.createReadStream(path).pipe(signal);
        signal.on("finish", () => {
            resolve();
        });

        signal.on('error', function (err) {
            reject();
        });
    });
}

function downloadFileAsync(uri, dest, cb) {
    return new Promise((resolve, reject) => {
        // 确保dest路径存在
        const file = fs.createWriteStream(dest);

        http.get(uri, (res) => {
            if (res.statusCode !== 200) {
                reject(response.statusCode);
                return;
            }

            res.on('end', () => {
                // log
            });

            // 进度、超时等
            const len = parseInt(res.headers['content-length']) // 文件总长度
            let cur = 0
            let lastProgress = "0";
            const total = (len / 1048576).toFixed(2) // 转为M 1048576 - bytes in  1Megabyte
            res.on('data', function (chunk) {
                cur += chunk.length
                const progress = (100.0 * cur / len).toFixed(0) // 当前进度
                const currProgress = (cur / 1048576).toFixed(2) // 当前了多少
                if (lastProgress != progress) {
                    lastProgress = progress;
                    cb(progress, currProgress, total);
                }
            })

            file.on('finish', () => {
                file.close(resolve);
            }).on('error', (err) => {
                fs.unlink(dest);
                reject(err.message);
            })

            res.pipe(file);
        });
    });
}

function exist(path) {
    try {
        fs.statSync(path);
        return true;
    } catch (error) {
        return false;
    }
}

function removeFolder(filePath) {
    return new Promise((resolve, reject) => {
        fs.stat(filePath, function (err, stat) {
            if (err) {
                reject(err);
                return;
            }
            if (stat.isFile() || stat.isSymbolicLink()) {
                fs.unlink(filePath, function (err) {
                    if (err) {
                        reject(err)
                        return;
                    }
                    resolve()
                })
            } else {
                fs.readdir(filePath, function (err, dirs) {
                    if (err) {
                        reject(err);
                        return;
                    }
                    dirs = dirs.map(dir => path.join(filePath, dir))
                    dirs = dirs.map(dir => removeFolder(dir))
                    Promise.all(dirs).then(() => {
                        fs.rmdir(filePath, resolve)
                    })
                })
            }
        })
    })
}

function copyFolder(copiedPath, resultPath) {
    function createDir(dirPath) {
        fs.mkdirSync(dirPath)
    }

    if (fs.existsSync(copiedPath)) {
        createDir(resultPath)
        /**
         * @des 方式一：利用子进程操作命令行方式
         */
        // child_process.spawn('cp', ['-r', copiedPath, resultPath])

        /**
         * @des 方式二：
         */
        const files = fs.readdirSync(copiedPath, { withFileTypes: true });
        for (let i = 0; i < files.length; i++) {
            const cf = files[i]
            const ccp = path.join(copiedPath, cf.name)
            const crp = path.join(resultPath, cf.name)
            if (cf.isFile()) {
                /**
                 * @des 创建文件,使用流的形式可以读写大文件
                 */
                const readStream = fs.createReadStream(ccp)
                const writeStream = fs.createWriteStream(crp)
                readStream.pipe(writeStream)
            } else {
                try {
                    /**
                     * @des 判断读(R_OK | W_OK)写权限
                     */
                    fs.accessSync(path.join(crp, '..'), fs.constants.W_OK)
                    copyFolder(ccp, crp, true);
                } catch (error) {
                    Editor.error('folder write error:', error);
                }

            }
        }
    } else {
        Editor.error('do not exist path: ', copiedPath);
    }
}


/**
 * 环境信息
 */
let engineEditorPath = path.dirname(path.dirname(Editor.frameworkPath));
let engineVersion = null;
let useGlobalEngineSettings = false;
let useServicePackJSVersion = "";
let useServicePackCPPVersion = "";
let useServicePackJSBVersion = "";
let canInstallPackVersions = [];
let config = {};
let lastVersion = "";


function updateInfomation() {
    canInstallPackVersions = getServicePackVersions(engineVersion);
    useServicePackJSBVersion = getJSBAdapterVersion();
    const settings = readCustomEngineSettings();
    if (settings) {
        if (settings["use-global-engine-setting"]) {
            useGlobalEngineSettings = true;
        } else {
            useGlobalEngineSettings = false;
            useServicePackJSVersion = getJavaScriptEngineVersion(settings);
            useServicePackCPPVersion = getCppEngineVersion(settings);
        }
    } else {
        useGlobalEngineSettings = true;
    }
}

function readCustomEngineSettings() {
    try {
        const content = JSON.parse(fs.readFileSync(path.join(path.dirname(Editor.url("db://assets/")), "local", "settings.json")));
        return content;
    } catch (error) {
        // Editor.error(error);
        return null;
    }
}

function getJavaScriptEngineVersion(settings) {
    if (settings["use-default-js-engine"]) {
        return "";
    } else {
        try {
            return fs.readFileSync(path.join(settings["js-engine-path"], "VERSION.md"), { encoding: "utf-8" }).trim();
        } catch (error) {
            // Editor.error(error);
            return "";
        }
    }
}

function getCppEngineVersion(settings) {
    if (settings["use-default-cpp-engine"]) {
        return "";
    } else {
        try {
            return fs.readFileSync(path.join(settings["cpp-engine-path"], "VERSION.md"), { encoding: "utf-8" }).trim();
        } catch (error) {
            // Editor.error(error);
            return "";
        }
    }
}

function getJSBAdapterVersion() {
    try {
        return fs.readFileSync(path.join(engineEditorPath, "builtin", "jsb-adapter", "VERSION.md"), { encoding: "utf-8" }).trim();
    } catch (error) {
        // Editor.error(error);
        return "";
    }
}

function getServicePackVersions(engineVersion) {
    try {
        const str = fs.readFileSync(path.join(Editor.url("packages://enhance-kit"), "packages", "config.json"), { encoding: "utf-8" });
        config = JSON.parse(str);
        lastVersion = config.lastVersion;
        return config[engineVersion] ? Object.keys(config[engineVersion]) : [];
    } catch (error) {
        // Editor.error(error);
        return [];
    }
}


/**
 * 修改自定义引擎设置
 */
function wirteCustomEngineSettings(settings) {
    try {
        fs.writeFileSync(path.join(path.dirname(Editor.url("db://assets/")), "local", "settings.json"), JSON.stringify(settings));
        return true;
    } catch (error) {
        Editor.error(error);
        return false;
    }
}


module.exports = {

    async load() {
        Editor.Scene.callSceneScript('enhance-kit', 'scene-get-engine-version', function (err, version) {
            if (version) {
                engineVersion = version;
                updateInfomation();
            }
        });
    },

    messages: {

        printInfomation() {
            Editor.info("----- Cocos Enhance Kit Infomation -----");
            Editor.info("当前引擎版本：", "v" + engineVersion);
            if (canInstallPackVersions.length == 0) {
                Editor.error("该引擎版本不支持一键安装增强包");
                Editor.error("你可以通过手动安装的方式进行安装：https://smallmain.github.io/cocos-enhance-kit/docs/installation-guide/installation-manual");
            } else {
                Editor.info("支持安装的增强包版本：", canInstallPackVersions.map(v => "v" + v).join(", "));
            }

            Editor.info("------------- 已安装增强包信息 -------------");
            if (useGlobalEngineSettings) {
                Editor.warn("项目自定义引擎正在使用全局配置，无法读取到已安装的增强包信息");
            } else {
                Editor.info("JavaScript 引擎的增强包：");
                if (useServicePackJSVersion) {
                    Editor.success("v" + useServicePackJSVersion);
                } else {
                    Editor.log("未安装");
                }

                Editor.info("C++ 引擎的增强包：");
                if (useServicePackCPPVersion) {
                    Editor.success("v" + useServicePackCPPVersion);
                } else {
                    Editor.log("未安装");
                }

                Editor.info("Jsb-Adapter 的增强包：");
                if (useServicePackJSBVersion) {
                    Editor.success("v" + useServicePackJSBVersion);
                } else {
                    Editor.log("未安装");
                }
            }
            Editor.info("-----------------------------------------");
            Editor.info("感谢你对 Cocos Enhance Kit 开源项目的支持。");
            Editor.info("-----------------------------------------");
        },

        async install(sender, version) {
            if (version == "last") version = lastVersion;

            let success = true;

            if (!canInstallPackVersions.includes(version)) {
                Editor.error("增强包版本 ", "v" + version, " 不能在此版本引擎上安装");
                return;
            }

            try {
                const curConfig = config[String(engineVersion)][version];
                const baseInstallPath = path.join(Editor.url("packages://enhance-kit"), "packages", String(engineVersion), version);
                const enginePath = path.join(baseInstallPath, "engine");
                const cocos2dxPath = path.join(baseInstallPath, "cocos2d-x");
                const jsbPath = path.join(baseInstallPath, "jsb-adapter");
                const dtsPath = path.join(baseInstallPath, "creator-sp.d.ts");

                Editor.log("正在检查增强包目录，版本 ", "v" + version, "，请勿操作...");

                // 检查是否有这个目录，没有则需要解压 zip 包
                if (!exist(baseInstallPath)) {
                    const zipPath = path.join(Editor.url("packages://enhance-kit"), "packages", String(engineVersion), version + ".zip");
                    const unzipPath = path.dirname(baseInstallPath);
                    Editor.info("如果是因为下载或者解压问题导致无法安装，非常抱歉，你可以在 " + curConfig.webDiskUrl + " 手动下载增强包 zip 文件，并放在 " + unzipPath + " 目录然后重试");
                    // 检查是否有 zip 包，没有则需要下载
                    if (!exist(zipPath)) {
                        const zipUrl = curConfig.downloadUrl;
                        Editor.log("本地不存在该版本增强包，开始下载...");
                        await downloadFileAsync(zipUrl, zipPath, (progress) => {
                            Editor.info("正在下载中...", progress);
                        });
                    }

                    Editor.info("正在删除旧目录...");
                    try {
                        await removeFolder(baseInstallPath);
                    } catch (error) {
                    }
                    Editor.info("正在解压...");
                    try {
                        await extract(zipPath, { dir: unzipPath });
                    } catch (error) {
                        await removeFolder(zipPath);
                        Editor.error("解压失败，可能是压缩包损坏，已将压缩包删除，请重新再试");
                        throw error;
                    }
                }

                Editor.log("正在安装增强包，版本 ", "v" + version, "，请勿操作...");

                let settings = readCustomEngineSettings();
                if (!settings) {
                    settings = {
                        "use-global-engine-setting": false,
                        "use-default-js-engine": false,
                        "js-engine-path": "",
                        "use-default-cpp-engine": false,
                        "cpp-engine-path": "",
                    }
                }
                settings["use-global-engine-setting"] = false;

                // 安装 JavaScript 引擎
                if (exist(enginePath)) {
                    settings["use-default-js-engine"] = false;
                    settings["js-engine-path"] = enginePath;
                    Editor.success("成功安装 JavaScript 引擎部分");
                } else {
                    Editor.warn("该版本增强包不存在 JavaScript 引擎部分，已跳过");
                }

                // 安装 Cpp 引擎
                if (exist(cocos2dxPath)) {
                    settings["use-default-cpp-engine"] = false;
                    settings["cpp-engine-path"] = cocos2dxPath;
                    Editor.success("成功安装 C++ 引擎部分");
                } else {
                    Editor.warn("该版本增强包不存在 C++ 引擎部分，已跳过");
                }

                if (wirteCustomEngineSettings(settings)) {
                    Editor.success("成功写入自定义引擎配置");
                } else {
                    Editor.error("写入自定义引擎配置失败");
                    success = false;
                }

                // 安装 jsb-adapter
                if (exist(jsbPath)) {
                    try {
                        const distPath = path.join(engineEditorPath, "builtin", "jsb-adapter");
                        await removeFolder(distPath);
                        copyFolder(jsbPath, distPath);
                    } catch (error) {
                        Editor.error(error);
                        Editor.error("替换 jsb-adapter 失败");
                        success = false;
                    }
                } else {
                    Editor.warn("该版本增强包不存在 jsb-adapter 部分，已跳过");
                }

                // 写入 creator-sp.d.ts
                if (exist(dtsPath)) {
                    fs.writeFileSync(path.join(path.dirname(Editor.url("db://assets/")), "creator-sp.d.ts"), fs.readFileSync(dtsPath));
                    Editor.success("成功写入 creator-sp.d.ts");
                } else {
                    Editor.error("写入 creator-sp.d.ts 失败");
                    success = false;
                }

                if (success) Editor.success("安装成功，请重启编辑器生效");
            } catch (error) {
                Editor.error(error);
            }
        },

        async uninstall() {
            Editor.log("正在卸载当前安装的增强包，请勿操作...");

            let success = true;

            // 还原自定义引擎
            const settings = readCustomEngineSettings();
            if (!settings || settings["use-global-engine-setting"]) {
                Editor.warn("项目自定义引擎正在使用全局配置，无法自动修改，请手动还原全局配置");
                success = false;
            } else {
                settings["use-default-js-engine"] = true;
                settings["use-default-cpp-engine"] = true;
                if (wirteCustomEngineSettings(settings)) {
                    Editor.log("已还原自定义引擎设置");
                } else {
                    Editor.error("修改项目自定义引擎失败，请手动还原自定义引擎设置");
                    success = false;
                }
            }

            // 还原 jsb-adapter
            const jsbBackupPath = path.join(Editor.url("packages://enhance-kit"), "packages", String(engineVersion), "backup", "jsb-adapter");
            if (exist(jsbBackupPath)) {
                try {
                    const distPath = path.join(engineEditorPath, "builtin", "jsb-adapter");
                    await removeFolder(distPath);
                    copyFolder(jsbBackupPath, distPath);
                    Editor.log("已还原 jsb-adapter 目录");
                } catch (error) {
                    console.error(error);
                    Editor.error("还原 jsb-adapter 目录失败，请手动还原 jsb-adapter 目录");
                    success = false;
                }
            } else {
                Editor.error("没有备份的 jsb-adapter 目录，请手动还原 jsb-adapter 目录");
                success = false;
            }

            // 还原 creator-sp.d.ts
            try {
                fs.unlinkSync(path.join(path.dirname(Editor.url("db://assets/")), "creator-sp.d.ts"));
                Editor.log("已删除 creator-sp.d.ts 文件");
            } catch (error) {

            }

            if (success) Editor.log("已卸载，请重启编辑器生效");
        },

        printWebsite() {
            Editor.info("Cocos Enhance Kit 官方网站：https://smallmain.github.io/cocos-enhance-kit");
        },

        "scene:ready"(event) {
            Editor.Scene.callSceneScript('enhance-kit', 'scene-get-engine-version', function (err, version) {
                if (version) {
                    engineVersion = version;
                    updateInfomation();
                }
            });
        },

    },

};
