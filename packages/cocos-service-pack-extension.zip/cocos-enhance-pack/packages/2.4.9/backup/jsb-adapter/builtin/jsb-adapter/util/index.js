function noop() {}

module.exports = noop;
