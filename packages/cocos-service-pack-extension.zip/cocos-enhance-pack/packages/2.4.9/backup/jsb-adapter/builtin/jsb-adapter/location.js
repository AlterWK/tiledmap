const location = {
    href: 'game.js',
    pathname: 'game.js',
    search: '',
    hash: '',
    reload() {
    }
}

module.exports = location;
