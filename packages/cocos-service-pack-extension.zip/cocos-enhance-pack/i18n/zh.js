module.exports = {
    'name': '增强包管理',
    'menuname': '增强包管理...',
    'installmenuname': '安装增强包...',
    'viewmenuname': '查看信息',
    'uninstallmenuname': '卸载增强包',
    'newmenuname': '安装最新版本',
    'allmenuname': '安装其它版本...',
    'websitemenuname': '官方网站',
};
