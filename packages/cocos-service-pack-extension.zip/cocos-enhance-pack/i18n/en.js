module.exports = {
    'name': 'Enhance Kit',
    'menuname': 'Enhance Kit...',
    'installmenuname': 'Install Enhance Kit',
    'viewmenuname': 'Print Infomation',
    'uninstallmenuname': 'Uninstall Enhance Kit',
    'newmenuname': 'Install Latest Version',
    'allmenuname': 'Install Other Version...',
    'websitemenuname': 'Official Website',
};
